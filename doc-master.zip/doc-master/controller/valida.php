<?php

 $user_name = $_POST['email'];
  
  $doc = $_POST['doc'];
$data=Now();

$dbc = mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');

	$query1 = "insert into action(id,dataInicio,nome,processoNegocio,aguardandoProcesso)Values(null,now(),'$user_name','$doc', Aprovado);";

$salva= mysqli_query($dbc, $query1);


header("Location:../view/ValidaDoc.php");
    
