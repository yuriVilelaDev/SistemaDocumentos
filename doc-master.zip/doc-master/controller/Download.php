<?php
session_start();
$funcionario = $_SESSION['funcionario'];
$dbc=  mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
$busqueId = ("SELECT id_users FROM users where nome = '$funcionario' ;");
$dado = mysqli_query( $dbc,$busqueId) ;

    $connect = mysqli_connect('107.180.46.155', 'vlela', '20berv18', 'DocumentosLab');
    
    $query="SELECT arquivo  FROM upload  where users_id_users = '$idUser'; ";
    $dados = mysqli_query($connect,$query);
	/*
	 * Dica: Sempre mantenha os arquivos de download em uma mesma pasta, separada dos arquivos do site.
	 * Neste script usaremos a pasta download para esta fun��o.
	 */

	$arquivo = $dados; // Nome do Arquivo
	$local = '/Documento/'; // Pasta que cont�m os arquivos para download
	$local_arquivio = $local.$arquivo; // Concatena o diret�rio com o nome do arquivo
	
	/*
	 * Por seguran�a, o script verifica se o usu�rio esta tentato sair da pasta especificada para 
	 * os arquivos de download (stripos($arquivo, './') !== false || stripos($arquivo, '../') !== false),
	 * isso ir� bloquear a tentativa de for�ar download de arquivos n�o permitidos.
	 * Na mesma fun��o verificamos se o arquivo existe (!file_exists($arquivo)).
	 */
    if(stripos($arquivo, './') !== false || stripos($arquivo, '../') !== false || !file_exists($local_arquivio))
    {
    	echo 'O comando n�o pode ser executado.';
    }
    else
    {
	    header('Cache-control: private');
	    header('Content-Type: application/octet-stream');
	    header('Content-Length: '.filesize($local_arquivio));
	    header('Content-Disposition: filename='.$arquivo);
	    header("Content-Disposition: attachment; filename=".basename($local_arquivio));
	    
	    // Envia o arquivo Download
		readfile($local_arquivio);
    }
?>