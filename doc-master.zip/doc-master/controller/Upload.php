<?php
session_start();
$user_name = $_SESSION['usuario'];
$dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
$perfil = "SELECT id_users FROM users WHERE nome='$user_name'"; 
$id = mysqli_query($dbc, $perfil);
$row= mysqli_fetch_array($id);
$resultado = $row['id_users'];
$uploaddir = 'Documento/';
$uploadfile = $uploaddir . basename($_FILES['arquivo']['name']);

echo '<pre>';
if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $uploadfile)) {

	$idUser = $resultado;
	  $doc = $_FILES['arquivo']['name'];
	  $data;     
	$query ="insert into upload(arquivo,users_id_users)values('$doc','$idUser');";
	$query1 = "insert into action(dataInicio,nome,processoNegocio,aguardandoProcesso,idUser)Values(now,'$user_name',Upload dos documentos, Aprovação);";
$salva1= mysqli_query($dbc,$query1);
$salva= mysqli_query($dbc, $query);

$_SESSION['condicao'] = 1;
header("Location:../view/historicoAcao.php");
    
} else {
	$_SESSION['condicao'] = 0;
	header("Location:../view/UploadArquivos.php");
}