<?php
session_start();

  $login = $_POST['email'];
  
  $senha = $_POST['pass'];
  
  $connect = mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
  
$query="SELECT * FROM users WHERE email = '$login' AND senha = MD5('$senha')";
             
      $verifica = mysqli_num_rows( mysqli_query($connect,$query));
    
       $cod = mysqli_fetch_array(mysqli_query($connect,$query));
       echo $cod['nivel'];
    if ($verifica != 0){
        $_SESSION['usuario'] = $_POST['email'];
        if($cod['nivel'] ==2){
            header("Location: /doc/view/GestaoRH.php");
        }
        else{
            header("Location: /doc/view/Menu.php");
        }
        
        
        
        
        
        
        
        
     }else{
    
     header("view/Login.html");
        }
        