<?php


session_start();
$user_name = $_SESSION['usuario'];
    $dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
    $perfil = "SELECT id_users FROM users WHERE nome='$user_name'"; 
    $id = mysqli_query($dbc, $perfil);
    $row= mysqli_fetch_array($id);
    $resultado = $row['id_users'];
    
            

            // obtem os dados do formulario digitados pelo usuario
           $nome = $_POST['Nome'];
           $carteiraTrabalho = $_POST['Carteira'];
           $certidaoNascimento  = $_POST['Certidão'];
           $escolaridade = $_POST['certificado'];
           $rg = $_POST['RH'];
           $pisPasep  = $_POST['PIS'];
           $crm = $_POST['crm'];
           $tituloEleitor = $_POST['titulo'];
           $conta  = $_POST['conta'];
           $cpf = $_POST ['cpf'];
           $dataNascimento = $_POST['Data'];
           $lattes = $_POST['url'];
           $idUser = $resultado;
           
          $query ="UPDATE perfil SET Nome = '$nome', DataNascimento = '$dataNascimento',CarteiraTrabalho='$carteiraTrabalho',
          CertidaoNascimento = '$certidaoNascimento', Escolaridade='$escolaridade',identidade= '$rg',CRM='$crm',
          pisPasep='$pisPasep',TituloEleitor='$tituloEleitor',conta= '$conta',CPF='$cpf', lattes= '$lattes' WHERE IdUser = '$idUser';";
     
$data= mysqli_query($dbc, $query);


//Redireciona pro diretorio desejado 
header("Location:../view/Perfil.php");
 
exit;