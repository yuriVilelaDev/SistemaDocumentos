<?php
//conecta-se ao banco de dados
try {
    $dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
            // obtem os dados do formulario digitados pelo usuario
           $idUp = $_POST['codigo'];
           $Status = $_POST['status'];
     // echo '<pre>'; var_dump($_POST); die();
          
           $query ="UPDATE upload SET `situacao_ID_SITUACAO`='$Status' WHERE `id_upload`='$idUp';";
     
$data= mysqli_query($dbc, $query);

$dbc = null;
header("Location: ../view/GerenciaDoc.php");

} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}