<?php
//conecta-se ao banco de dados
try {
       $dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
            
            // obtem os dados do formulario digitados pelo usuario
           $Usu = $_POST['nome'];
           $Senha = $_POST['senha'];
           $Mail  = $_POST['email'];
           $cargos = $_POST['cargo'];
           if($cargos == 'R.H'){
               $cargos = 2;
           }else{
               $cargos =1;
           }
          
           $query ="insert into users values (null,'$Usu',MD5('$Senha'),'$Mail','$cargos');";
     
$data= mysqli_query($dbc, $query);

$dbc = null;
header("Location: ../view/Admfuncionario.php");

} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}  