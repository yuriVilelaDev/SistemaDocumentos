<?php
//conecta-se ao banco de dados

try {
     $dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');;
            
            // obtem os dados do formulario digitados pelo usuario
           $doc = $_POST['doc'];
           $Senha = $_POST['Senha'];


           $query ="insert into documento (tipo)values('$doc');";
     
$data= mysqli_query($dbc, $query);
        
$dbc = null;

header("Location: ../view/RelacaoDoc.php");

} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}  