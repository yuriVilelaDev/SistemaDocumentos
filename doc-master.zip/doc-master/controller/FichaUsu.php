<?php


session_start();
$user_name = $_SESSION['usuario'];
    $dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
    $perfil = "SELECT id_users FROM users WHERE nome='$user_name'"; 
    $id = mysqli_query($dbc, $perfil);
    $row= mysqli_fetch_array($id);
    $resultado = $row['id_users'];
    
            

            // obtem os dados do formulario digitados pelo usuario
           $nome = $_POST['Nome'];
           $carteiraTrabalho = $_POST['Carteira'];
           $certidaoNascimento  = $_POST['Certidão'];
           $escolaridade = $_POST['certificado'];
           $rg = $_POST['RH'];
           $pisPasep  = $_POST['PIS'];
           $crm = $_POST['crm'];
           $tituloEleitor = $_POST['titulo'];
           $conta  = $_POST['conta'];
           $cpf = $_POST ['cpf'];
           $dataNascimento = $_POST['Data'];
           $endereco = $_POST['Endereço'];
           $cargo  = $_POST['Cargo'];
           $lattes = $_POST['Currículo'];
           $idUser = $resultado;
           
          $query ="insert into perfil(Nome, DataNascimento, CarteiraTrabalho, CertidaoNascimento, Escolaridade, identidade, pisPasep, 
                                        CRM, TituloEleitor, conta, CPF, Cargo, lattes,IdUser )
            values('$nome','$dataNascimento','$carteiraTrabalho','$certidaoNascimento','$escolaridade','$rg','$pisPasep','$crm','$tituloEleitor',
            '$conta','$cpf','$cargo','$lattes','$idUser');";
     
$data= mysqli_query($dbc, $query);


//Redireciona pro diretorio desejado 
header("Location:../view/Perfil.php");
 
exit;

/*echo  $nome;
echo $certidaoNascimento;
echo $escolaridade ;
echo $carteiraTrabalho ;
echo $rg;
echo $pisPasep;
echo $crm ;
echo $tituloEleitor; 
echo $conta  ;
echo $cpf ;
echo $dataNascimento; 
echo $endereco ;
echo $cargo  ;
echo $lattes ;
echo $idUser; */