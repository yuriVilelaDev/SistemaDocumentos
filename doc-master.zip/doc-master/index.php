<?php
/* Redireciona pro diretorio desejado */
header("Location: /doc/view/Login.html");
 
exit;
?>