<?php
session_start();
$user_name = $_SESSION['usuario'];
$idUser = $_SESSION['iduse'];
$dbc= mysqli_connect('localhost', 'vilela', '20berv18', 'DocumentosLab');
$sobAnalise = ("SELECT * FROM perfil where IdUser = '$idUser';");
$dados = mysqli_query( $dbc,$sobAnalise) ;
$total = mysqli_num_rows($dados);
$analise = mysqli_fetch_array($dados);
?>
<!DOCTYPE html>
<html lang="pt-br" class="ls-theme-orange ls-html-nobg ls-main-full">

<head>
  <title>Fake Product Name</title>
 <meta charset="utf-8">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="description" content="Insira aqui a descrição da página.">
    <link href="http://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <link rel="icon" sizes="192x192" href="/locawebstyle/assets/images/ico-boilerplate.png">
    <link rel="apple-touch-icon" href="/locawebstyle/assets/images/ico-boilerplate.png">
</head>
<body class="documentacao documentacao_exemplos documentacao_exemplos_painel1 documentacao_exemplos_painel1_client documentacao_exemplos_painel1_client_index">

  <div class="ls-topbar ">

  <!-- Barra de Notificações -->
  <div class="ls-notification-topbar">

    <!-- Links de apoio -->
  <!--  <div class="ls-alerts-list">
      <a href="#" class="ls-ico-bullhorn" data-ls-module="topbarCurtain" data-target="#ls-help-curtain"><span>Ajuda</span></a>
      <a href="#" class="ls-ico-question" data-ls-module="topbarCurtain" data-target="#ls-feedback-curtain"><span>Sugestões</span></a>
    </div>-->

    <!-- Dropdown com detalhes da conta de usuário -->
    <div data-ls-module="dropdown" class="ls-dropdown ls-user-account">
      <a href="#" class="ls-ico-user">
        <img src="/locawebstyle/assets/images/locastyle/avatar-example.jpg" alt="" />
        <span class="ls-name"><?php echo  $_SESSION['usuario']; ?></span>
        
      </a>

      <nav class="ls-dropdown-nav ls-user-menu">
        <ul>
          <li><a href="Login.html">Sair</a></li>
         </ul>
      </nav>
    </div>
  </div>
  <span class="ls-show-sidebar ls-ico-menu"></span>

  <!-- Nome do produto/marca com sidebar -->
  <h1 class="ls-brand-name">
      <a href="Menu.php" class="ls-ico-multibuckets">
        <small>Faculdade Pitágoras - Contagem</small>
        Sistema de Documentações
      </a>
    </h1>

  <!-- Nome do produto/marca sem sidebar quando for o pre-painel  -->
    </div>
 <aside class="ls-sidebar">
  <div class="ls-sidebar-inner">
      <a href="/view/Menu.php"  class="ls-go-prev"><span class="ls-text">Voltar à lista de serviços</span></a>
      <nav class="ls-menu">
        <ul>
           <li><a href="#" class="ls-ico-dashboard" title="-">-</a></li>
           <li><a href="#" class="ls-ico-users" title="-">-</a></li>
           <li><a href="#" class="ls-ico-stats" title="-">-</a></li>
        </ul>
      </nav>
  </div>
</aside>



  <main class="ls-main ">
    <div class="container-fluid">
      <h1 class="ls-title-intro ls-ico-users">Dados do Usuário</h1>

<div class="ls-box">


  <form action="" class="ls-form ls-form-horizontal ls-form-text" data-ls-module="form">
    <fieldset id="domain-form" class=" ls-form-horizontal">
  
                 
        
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Nome Completo:</b>
        <input type='text' value=<?php echo $analise['Nome']?> required>
      </label>  
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Data de Nascimento:</b>
        <input type='text' value=<?php echo $analise['DataNascimento']?> required>
      </label> 
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Carteira de trabalho:</b>
        <input type='text' value=<?php echo $analise['CarteiraTrabalho']?> required>
      </label> 
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Certidão de Nascimento:</b>
        <input type='text' value=<?php echo $analise['CertidaoNascimento']?> required>
      </label>  
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Escolaridade:</b>
        <input type='text' value=<?php echo $analise['Escolaridade']?> required>
      </label> 
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Identidade:</b>
        <input type='text' value=<?php echo $analise['identidade']?>required>
      </label>  
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Número do PIS/PASEP:</b>
        <input type='text' value=<?php echo $analise['pisPasep']?> required>
      </label> 
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Certificado de Reservista:</b>
        <input type='text' value=<?php echo $analise['CRM']?> required>
      </label>  
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Título de Eleitor:</b>
        <input type='text' value=<?php echo $analise['TituloEleitor']?> required>
      </label> 
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Conta Bancária:</b>
        <input type='text' value=<?php echo $analise['conta']?> required>
      </label>  
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>CPF:</b>
        <input type='text' value=<?php echo $analise['CPF']?> required>
      </label> 
        
            <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Cargo:</b>
        <input type='text' value=<?php echo $analise['Cargo']?> required>
     </label> 
        <label class='ls-label col-md-6 col-lg-8'>
        <b class='ls-label-text'>Currículo Lattes:</b>
       <a href="<?php echo $analise['lattes']?>"> <input type='text' value=<?php echo $analise['lattes']?> required></a>
      </label>  
    </fieldset>
  </form>
  <a href="EditaPerfil.php" class="ls-btn">Editar</a>
</div>
 </div>
  </main>


  <script src="../../../../assets/javascripts/libs/jquery-2.1.0.min.js" type="text/javascript"></script><script src="../../../../assets/javascripts/example.js" type="text/javascript"></script><script src="../../../../assets/javascripts/locastyle.js" type="text/javascript"></script><script src="//code.highcharts.com/highcharts.js" type="text/javascript"></script><script src="../../../../assets/javascripts/docs/panel-charts.js" type="text/javascript"></script>

  <script type="text/javascript">
    $(window).on('load', function() {
      locastyle.browserUnsupportedBar.init();
    });
  </script>

</body>
</html>
